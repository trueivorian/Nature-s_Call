﻿using UnityEngine;
using System.Collections;

public class Enemy : Character {

	protected float knockBackDist;
	// Can't red the other attribute of the UML diagram

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	// Moves the enemy in the pattern decided in the subclass
	void move(){

	}
}
