﻿using UnityEngine;
using System.Collections;

public class Rat : Enemy {

	public static Rat ratInstance;

	private bool isJumping;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
